package cl.bueno.cliente;

import cl.bueno.cliente.dto.ClienteRequest;
import cl.bueno.cliente.dto.ClienteResponse;
import cl.bueno.cliente.service.ClienteService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test") // 🔥 ESTE ES EL CAMBIO CLAVE
class ClienteApplicationTests {

    @Autowired
    private ClienteService servicio;

    private Long clienteId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            ClienteRequest request = ClienteRequest.builder()
                    .nombre("Juan Perez")
                    .email("juan@gmail.com")
                    .telefono("987654321")
                    .activo(true)
                    .build();

            ClienteResponse response = servicio.create(request);
            clienteId = response.getId();

        } else {

            clienteId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando nombre del cliente")
    void checkNombreCliente() {

        ClienteResponse cliente = servicio.findById(clienteId);

        log.info("Revisando cliente {}", cliente.getNombre());

        assertEquals("Juan Perez", cliente.getNombre());
    }

    @Test
    @DisplayName("Revisando email del cliente")
    void checkEmailCliente() {

        ClienteResponse cliente = servicio.findById(clienteId);

        log.info("Revisando email {}", cliente.getEmail());

        assertEquals("juan@gmail.com", cliente.getEmail());
    }

    @Test
    @DisplayName("Revisando largo del teléfono")
    void checkTelefonoCliente() {

        ClienteResponse cliente = servicio.findById(clienteId);

        log.info("Revisando teléfono {}", cliente.getTelefono());

        assertEquals(9, cliente.getTelefono().length());
    }

    @Test
    @DisplayName("Verificando cliente activo")
    void checkClienteActivo() {

        ClienteResponse cliente = servicio.findById(clienteId);

        log.info("Verificando estado del cliente");

        assertTrue(cliente.getActivo());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadClientes() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad de clientes: {}", cantidad);

        assertEquals(1, cantidad);
    }
}