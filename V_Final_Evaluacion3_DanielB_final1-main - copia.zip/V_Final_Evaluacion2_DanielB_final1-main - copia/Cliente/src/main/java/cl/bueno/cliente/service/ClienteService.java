package cl.bueno.cliente.service;

import cl.bueno.cliente.dto.ClienteRequest;
import cl.bueno.cliente.dto.ClienteResponse;
import cl.bueno.cliente.exeption.ReglaNegocioException;
import cl.bueno.cliente.exeption.RecursoNoEncontradoException;
import cl.bueno.cliente.model.Cliente;
import cl.bueno.cliente.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public List<ClienteResponse> findAll() {
        log.info("Listando clientes");
        return clienteRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public ClienteResponse findById(Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado"));
        return toResponse(cliente);
    }

    public ClienteResponse create(ClienteRequest request) {
        if (clienteRepository.existsByEmailIgnoreCase(request.getEmail())) {
            throw new ReglaNegocioException("Ya existe un cliente con ese email");
        }

        Cliente cliente = Cliente.builder()
                .nombre(request.getNombre())
                .email(request.getEmail())
                .telefono(request.getTelefono())
                .activo(request.getActivo() != null ? request.getActivo() : true)
                .build();

        return toResponse(clienteRepository.save(cliente));
    }

    public ClienteResponse update(Long id, ClienteRequest request) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado"));

        cliente.setNombre(request.getNombre());
        cliente.setEmail(request.getEmail());
        cliente.setTelefono(request.getTelefono());
        cliente.setActivo(request.getActivo() != null ? request.getActivo() : cliente.getActivo());

        return toResponse(clienteRepository.save(cliente));
    }

    public void delete(Long id) {
        if (!clienteRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Cliente no encontrado");
        }
        clienteRepository.deleteById(id);
    }

    private ClienteResponse toResponse(Cliente cliente) {
        return ClienteResponse.builder()
                .id(cliente.getId())
                .nombre(cliente.getNombre())
                .email(cliente.getEmail())
                .telefono(cliente.getTelefono())
                .activo(cliente.getActivo())
                .build();
    }
}