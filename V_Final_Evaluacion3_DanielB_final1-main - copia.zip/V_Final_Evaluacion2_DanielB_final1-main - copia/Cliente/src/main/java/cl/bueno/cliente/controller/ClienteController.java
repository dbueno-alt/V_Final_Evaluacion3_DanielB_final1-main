package cl.bueno.cliente.controller;

import cl.bueno.cliente.dto.ClienteRequest;
import cl.bueno.cliente.dto.ClienteResponse;
import cl.bueno.cliente.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/clientes")
@RequiredArgsConstructor
@Tag(name = "API Cliente", description = "API para la gestión de clientes")
public class ClienteController {

    private final ClienteService clienteService;

    @GetMapping
    @Operation(
            summary = "Obtener todos los clientes",
            description = "Permite consultar todos los clientes registrados"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen clientes registrados")
    public ResponseEntity<List<ClienteResponse>> findAll() {

        List<ClienteResponse> clientes = clienteService.findAll();

        if (clientes.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(clientes, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar cliente por ID",
            description = "Obtiene la información de un cliente según su identificador"
    )
    @ApiResponse(responseCode = "200", description = "Cliente encontrado")
    @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    public ResponseEntity<ClienteResponse> findById(
            @Parameter(description = "ID del cliente")
            @PathVariable Long id) {

        return ResponseEntity.ok(clienteService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar cliente",
            description = "Permite registrar un nuevo cliente"
    )
    @ApiResponse(responseCode = "201", description = "Cliente registrado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<ClienteResponse> create(
            @Valid @RequestBody ClienteRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(clienteService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar cliente",
            description = "Actualiza la información de un cliente existente"
    )
    @ApiResponse(responseCode = "200", description = "Cliente actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    public ResponseEntity<ClienteResponse> update(
            @Parameter(description = "ID del cliente")
            @PathVariable Long id,
            @Valid @RequestBody ClienteRequest request) {

        return ResponseEntity.ok(clienteService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar cliente",
            description = "Elimina un cliente del sistema"
    )
    @ApiResponse(responseCode = "204", description = "Cliente eliminado correctamente")
    @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del cliente")
            @PathVariable Long id) {

        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }
}