CREATE TABLE clientes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre varchar(100) NOT NULL,
    email varchar(150) NOT NULL,
    telefono varchar(20) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);