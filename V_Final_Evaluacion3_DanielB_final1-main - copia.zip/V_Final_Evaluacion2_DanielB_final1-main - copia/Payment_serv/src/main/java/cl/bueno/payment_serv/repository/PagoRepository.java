package cl.bueno.payment_serv.repository;

import cl.bueno.payment_serv.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {
}
