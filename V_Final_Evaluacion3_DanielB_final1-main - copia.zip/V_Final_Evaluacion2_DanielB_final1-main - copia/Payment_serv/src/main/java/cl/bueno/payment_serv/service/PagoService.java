package cl.bueno.payment_serv.service;

import cl.bueno.payment_serv.dto.PagoRequest;
import cl.bueno.payment_serv.dto.PagoResponse;
import cl.bueno.payment_serv.exception.RecursoNoEncontradoException;
import cl.bueno.payment_serv.model.Pago;
import cl.bueno.payment_serv.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository pagoRepository;

    public List<PagoResponse> findAll() {
        return pagoRepository.findAll().stream().map(this::toResponse).toList();
    }

    public PagoResponse findById(Long id) {
        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado"));
        return toResponse(pago);
    }

    public PagoResponse create(PagoRequest request) {
        Pago pago = Pago.builder()
                .pedidoId(request.getPedidoId())
                .monto(request.getMonto())
                .metodoPago(request.getMetodoPago())
                .estadoPago(request.getEstadoPago())
                .referenciaTransaccion(request.getReferenciaTransaccion())
                .build();

        return toResponse(pagoRepository.save(pago));
    }

    public PagoResponse update(Long id, PagoRequest request) {
        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado"));

        pago.setPedidoId(request.getPedidoId());
        pago.setMonto(request.getMonto());
        pago.setMetodoPago(request.getMetodoPago());
        pago.setEstadoPago(request.getEstadoPago());
        pago.setReferenciaTransaccion(request.getReferenciaTransaccion());

        return toResponse(pagoRepository.save(pago));
    }

    public void delete(Long id) {
        if (!pagoRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Pago no encontrado");
        }
        pagoRepository.deleteById(id);
    }

    private PagoResponse toResponse(Pago pago) {
        return PagoResponse.builder()
                .id(pago.getId())
                .pedidoId(pago.getPedidoId())
                .monto(pago.getMonto())
                .metodoPago(pago.getMetodoPago())
                .estadoPago(pago.getEstadoPago())
                .referenciaTransaccion(pago.getReferenciaTransaccion())
                .build();
    }
}
