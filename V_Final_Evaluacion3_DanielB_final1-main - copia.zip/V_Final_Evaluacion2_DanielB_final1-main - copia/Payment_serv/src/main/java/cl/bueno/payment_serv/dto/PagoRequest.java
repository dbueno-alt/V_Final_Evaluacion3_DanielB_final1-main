package cl.bueno.payment_serv.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PagoRequest {

    @NotNull(message = "El pedido es obligatorio")
    private Long pedidoId;

    @NotNull(message = "El monto es obligatorio")
    @DecimalMin(value = "0.0", inclusive = true, message = "El monto no puede ser negativo")
    private BigDecimal monto;

    @NotNull(message = "El método de pago es obligatorio")
    @Size(max = 50, message = "El método de pago no puede superar 50 caracteres")
    private String metodoPago;

    @NotNull(message = "El estado del pago es obligatorio")
    @Size(max = 30, message = "El estado del pago no puede superar 30 caracteres")
    private String estadoPago;

    @Size(max = 100, message = "La referencia de transacción no puede superar 100 caracteres")
    private String referenciaTransaccion;
}