package cl.bueno.payment_serv.controller;

import cl.bueno.payment_serv.dto.PagoRequest;
import cl.bueno.payment_serv.dto.PagoResponse;
import cl.bueno.payment_serv.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/pagos")
@RequiredArgsConstructor
@Tag(name = "API Pago", description = "API para la gestión de pagos")
public class PagoController {

    private final PagoService pagoService;

    @GetMapping
    @Operation(
            summary = "Obtener todos los pagos",
            description = "Permite consultar todos los pagos registrados"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen pagos registrados")
    public ResponseEntity<List<PagoResponse>> findAll() {
        return ResponseEntity.ok(pagoService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar pago por ID",
            description = "Permite obtener un pago mediante su ID"
    )
    @ApiResponse(responseCode = "200", description = "Pago encontrado")
    @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    public ResponseEntity<PagoResponse> findById(
            @Parameter(description = "ID del pago")
            @PathVariable Long id) {

        return ResponseEntity.ok(pagoService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar un pago",
            description = "Permite registrar un nuevo pago"
    )
    @ApiResponse(responseCode = "201", description = "Pago creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<PagoResponse> create(
            @Valid @RequestBody PagoRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(pagoService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar pago",
            description = "Permite modificar la información de un pago existente"
    )
    @ApiResponse(responseCode = "200", description = "Pago actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<PagoResponse> update(
            @Parameter(description = "ID del pago")
            @PathVariable Long id,
            @Valid @RequestBody PagoRequest request) {

        return ResponseEntity.ok(pagoService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar pago",
            description = "Permite eliminar un pago mediante su ID"
    )
    @ApiResponse(responseCode = "204", description = "Pago eliminado correctamente")
    @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del pago")
            @PathVariable Long id) {

        pagoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}