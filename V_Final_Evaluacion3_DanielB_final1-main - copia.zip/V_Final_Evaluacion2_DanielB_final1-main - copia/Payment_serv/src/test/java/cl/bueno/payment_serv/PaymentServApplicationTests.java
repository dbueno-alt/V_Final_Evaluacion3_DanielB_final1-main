package cl.bueno.payment_serv;

import cl.bueno.payment_serv.dto.PagoRequest;
import cl.bueno.payment_serv.dto.PagoResponse;
import cl.bueno.payment_serv.service.PagoService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class PaymentServApplicationTests {

    @Autowired
    private PagoService servicio;

    private Long pagoId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            PagoRequest request = PagoRequest.builder()
                    .pedidoId(1L)
                    .monto(new BigDecimal("150.00"))
                    .metodoPago("TARJETA")
                    .estadoPago("COMPLETADO")
                    .referenciaTransaccion("TXN-12345")
                    .build();

            PagoResponse response = servicio.create(request);
            pagoId = response.getId();

        } else {
            pagoId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando pedidoId")
    void checkPedidoId() {

        PagoResponse pago = servicio.findById(pagoId);

        log.info("Pedido ID: {}", pago.getPedidoId());

        assertEquals(1L, pago.getPedidoId());
    }

    @Test
    @DisplayName("Revisando monto")
    void checkMonto() {

        PagoResponse pago = servicio.findById(pagoId);

        log.info("Monto: {}", pago.getMonto());

        assertEquals(new BigDecimal("150.00"), pago.getMonto());
    }

    @Test
    @DisplayName("Revisando método de pago")
    void checkMetodoPago() {

        PagoResponse pago = servicio.findById(pagoId);

        log.info("Método de pago: {}", pago.getMetodoPago());

        assertEquals("TARJETA", pago.getMetodoPago());
    }

    @Test
    @DisplayName("Revisando estado de pago")
    void checkEstadoPago() {

        PagoResponse pago = servicio.findById(pagoId);

        log.info("Estado: {}", pago.getEstadoPago());

        assertEquals("COMPLETADO", pago.getEstadoPago());
    }

    @Test
    @DisplayName("Revisando referencia transacción")
    void checkReferencia() {

        PagoResponse pago = servicio.findById(pagoId);

        log.info("Referencia: {}", pago.getReferenciaTransaccion());

        assertEquals("TXN-12345", pago.getReferenciaTransaccion());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadPagos() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad de pagos: {}", cantidad);

        assertEquals(1, cantidad);
    }
}