package cl.bueno.inventory_serv.service;

import cl.bueno.inventory_serv.dto.InventarioRequest;
import cl.bueno.inventory_serv.dto.InventarioResponse;
import cl.bueno.inventory_serv.exception.RecursoNoEncontradoException;
import cl.bueno.inventory_serv.model.Inventario;
import cl.bueno.inventory_serv.repository.InventarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventarioService {

    private final InventarioRepository inventarioRepository;

    public List<InventarioResponse> findAll() {
        return inventarioRepository.findAll().stream().map(this::toResponse).toList();
    }

    public InventarioResponse findById(Long id) {
        Inventario inventario = inventarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Inventario no encontrado"));
        return toResponse(inventario);
    }

    public InventarioResponse create(InventarioRequest request) {
        Inventario inventario = Inventario.builder()
                .productoId(request.getProductoId())
                .cantidadActual(request.getCantidadActual())
                .stockMinimo(request.getStockMinimo())
                .activo(request.getActivo() != null ? request.getActivo() : true)
                .build();

        return toResponse(inventarioRepository.save(inventario));
    }

    public InventarioResponse update(Long id, InventarioRequest request) {
        Inventario inventario = inventarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Inventario no encontrado"));

        inventario.setProductoId(request.getProductoId());
        inventario.setCantidadActual(request.getCantidadActual());
        inventario.setStockMinimo(request.getStockMinimo());
        inventario.setActivo(request.getActivo() != null ? request.getActivo() : inventario.getActivo());

        return toResponse(inventarioRepository.save(inventario));
    }

    public void delete(Long id) {
        if (!inventarioRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Inventario no encontrado");
        }
        inventarioRepository.deleteById(id);
    }

    private InventarioResponse toResponse(Inventario inventario) {
        return InventarioResponse.builder()
                .id(inventario.getId())
                .productoId(inventario.getProductoId())
                .cantidadActual(inventario.getCantidadActual())
                .stockMinimo(inventario.getStockMinimo())
                .activo(inventario.getActivo())
                .build();
    }
}