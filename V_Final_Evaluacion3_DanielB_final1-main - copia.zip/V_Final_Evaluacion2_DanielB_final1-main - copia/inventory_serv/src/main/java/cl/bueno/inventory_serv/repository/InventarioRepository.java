package cl.bueno.inventory_serv.repository;

import cl.bueno.inventory_serv.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventarioRepository extends JpaRepository<Inventario, Long> {
}
