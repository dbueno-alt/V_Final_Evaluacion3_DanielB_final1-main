package cl.bueno.inventory_serv.controller;

import cl.bueno.inventory_serv.dto.InventarioRequest;
import cl.bueno.inventory_serv.dto.InventarioResponse;
import cl.bueno.inventory_serv.service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/inventarios")
@RequiredArgsConstructor
@Tag(name = "API Inventario", description = "API para la gestión del inventario")
public class InventarioController {

    private final InventarioService inventarioService;

    @GetMapping
    @Operation(
            summary = "Obtener todo el inventario",
            description = "Permite consultar todos los registros del inventario"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen registros de inventario")
    public ResponseEntity<List<InventarioResponse>> findAll() {
        return ResponseEntity.ok(inventarioService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar inventario por ID",
            description = "Permite obtener un registro del inventario mediante su ID"
    )
    @ApiResponse(responseCode = "200", description = "Inventario encontrado")
    @ApiResponse(responseCode = "404", description = "Inventario no encontrado")
    public ResponseEntity<InventarioResponse> findById(
            @Parameter(description = "ID del inventario")
            @PathVariable Long id) {

        return ResponseEntity.ok(inventarioService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Crear inventario",
            description = "Permite registrar un nuevo inventario"
    )
    @ApiResponse(responseCode = "201", description = "Inventario creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<InventarioResponse> create(
            @Valid @RequestBody InventarioRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(inventarioService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar inventario",
            description = "Permite modificar un inventario existente"
    )
    @ApiResponse(responseCode = "200", description = "Inventario actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Inventario no encontrado")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<InventarioResponse> update(
            @Parameter(description = "ID del inventario")
            @PathVariable Long id,
            @Valid @RequestBody InventarioRequest request) {

        return ResponseEntity.ok(inventarioService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar inventario",
            description = "Permite eliminar un registro del inventario por su ID"
    )
    @ApiResponse(responseCode = "204", description = "Inventario eliminado correctamente")
    @ApiResponse(responseCode = "404", description = "Inventario no encontrado")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del inventario")
            @PathVariable Long id) {

        inventarioService.delete(id);
        return ResponseEntity.noContent().build();
    }
}