package cl.bueno.inventory_serv.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventarioResponse {
    private Long id;
    private Long productoId;
    private Integer cantidadActual;
    private Integer stockMinimo;
    private Boolean activo;
}
