package cl.bueno.inventory_serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryServApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventoryServApplication.class, args);
    }

}
