CREATE TABLE inventario (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    producto_id BIGINT NOT NULL,
    cantidad_actual INT NOT NULL,
    stock_minimo INT NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);