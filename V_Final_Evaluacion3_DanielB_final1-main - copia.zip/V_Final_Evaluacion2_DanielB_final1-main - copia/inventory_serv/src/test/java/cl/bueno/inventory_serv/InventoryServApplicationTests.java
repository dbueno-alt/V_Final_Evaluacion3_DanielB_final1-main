package cl.bueno.inventory_serv;

import cl.bueno.inventory_serv.dto.InventarioRequest;
import cl.bueno.inventory_serv.dto.InventarioResponse;
import cl.bueno.inventory_serv.service.InventarioService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class InventoryServApplicationTests {

    @Autowired
    private InventarioService servicio;

    private Long inventarioId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            InventarioRequest request = InventarioRequest.builder()
                    .productoId(1L)
                    .cantidadActual(50)
                    .stockMinimo(10)
                    .activo(true)
                    .build();

            InventarioResponse response = servicio.create(request);
            inventarioId = response.getId();

        } else {
            inventarioId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando productoId del inventario")
    void checkProductoId() {

        InventarioResponse inventario = servicio.findById(inventarioId);

        log.info("Producto ID: {}", inventario.getProductoId());

        assertEquals(1L, inventario.getProductoId());
    }

    @Test
    @DisplayName("Revisando cantidad actual")
    void checkCantidadActual() {

        InventarioResponse inventario = servicio.findById(inventarioId);

        log.info("Cantidad actual: {}", inventario.getCantidadActual());

        assertEquals(50, inventario.getCantidadActual());
    }

    @Test
    @DisplayName("Revisando stock mínimo")
    void checkStockMinimo() {

        InventarioResponse inventario = servicio.findById(inventarioId);

        log.info("Stock mínimo: {}", inventario.getStockMinimo());

        assertEquals(10, inventario.getStockMinimo());
    }

    @Test
    @DisplayName("Verificando inventario activo")
    void checkInventarioActivo() {

        InventarioResponse inventario = servicio.findById(inventarioId);

        log.info("Estado activo: {}", inventario.getActivo());

        assertTrue(inventario.getActivo());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadInventario() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad de inventarios: {}", cantidad);

        assertEquals(1, cantidad);
    }
}