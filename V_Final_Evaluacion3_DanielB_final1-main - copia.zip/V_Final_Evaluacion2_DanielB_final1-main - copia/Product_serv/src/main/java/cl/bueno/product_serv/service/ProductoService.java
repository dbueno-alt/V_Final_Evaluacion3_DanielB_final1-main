package cl.bueno.product_serv.service;

import cl.bueno.product_serv.DTO.ProductoRequest;
import cl.bueno.product_serv.DTO.ProductoResponse;
import cl.bueno.product_serv.Excepciones.ReglaNegocioException;
import cl.bueno.product_serv.Excepciones.RecursoNoEncontradoException;
import cl.bueno.product_serv.model.Producto;
import cl.bueno.product_serv.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductoService {

    private final ProductoRepository productoRepository;

    public List<ProductoResponse> findAll() {
        log.info("Listando productos");
        return productoRepository.findAll().stream().map(this::toResponse).toList();
    }

    public ProductoResponse findById(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado"));
        return toResponse(producto);
    }

    public ProductoResponse create(ProductoRequest request) {
        if (productoRepository.existsByNombreIgnoreCase(request.getNombre())) {
            throw new ReglaNegocioException("Ya existe un producto con ese nombre");
        }

        Producto producto = Producto.builder()
                .nombre(request.getNombre())
                .descripcion(request.getDescripcion())
                .precio(request.getPrecio())
                .stock(request.getStock())
                .activo(request.getActivo() != null ? request.getActivo() : true)
                .build();

        return toResponse(productoRepository.save(producto));
    }

    public ProductoResponse update(Long id, ProductoRequest request) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado"));

        producto.setNombre(request.getNombre());
        producto.setDescripcion(request.getDescripcion());
        producto.setPrecio(request.getPrecio());
        producto.setStock(request.getStock());
        producto.setActivo(request.getActivo() != null ? request.getActivo() : producto.getActivo());

        return toResponse(productoRepository.save(producto));
    }

    public void delete(Long id) {
        if (!productoRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Producto no encontrado");
        }
        productoRepository.deleteById(id);
    }

    private ProductoResponse toResponse(Producto producto) {
        return ProductoResponse.builder()
                .id(producto.getId())
                .nombre(producto.getNombre())
                .descripcion(producto.getDescripcion())
                .precio(producto.getPrecio())
                .stock(producto.getStock())
                .activo(producto.getActivo())
                .build();
    }
}