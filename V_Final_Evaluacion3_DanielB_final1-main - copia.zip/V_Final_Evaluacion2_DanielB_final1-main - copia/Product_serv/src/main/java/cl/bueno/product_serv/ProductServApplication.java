package cl.bueno.product_serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductServApplication.class, args);
    }

}