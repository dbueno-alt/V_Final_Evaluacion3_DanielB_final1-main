package cl.bueno.product_serv.controller;

import cl.bueno.product_serv.DTO.ProductoRequest;
import cl.bueno.product_serv.DTO.ProductoResponse;
import cl.bueno.product_serv.service.ProductoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
@RequiredArgsConstructor
@Tag(name = "API Producto", description = "API para la gestión de productos")
public class ProductoController {

    private final ProductoService productoService;

    @GetMapping
    @Operation(
            summary = "Obtener todos los productos",
            description = "Permite listar todos los productos registrados"
    )
    @ApiResponse(responseCode = "200", description = "Consulta exitosa")
    public ResponseEntity<List<ProductoResponse>> findAll() {
        return ResponseEntity.ok(productoService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar producto por ID",
            description = "Permite obtener un producto por su identificador"
    )
    @ApiResponse(responseCode = "200", description = "Producto encontrado")
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    public ResponseEntity<ProductoResponse> findById(
            @Parameter(description = "ID del producto")
            @PathVariable Long id) {

        return ResponseEntity.ok(productoService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Crear producto",
            description = "Permite registrar un nuevo producto"
    )
    @ApiResponse(responseCode = "201", description = "Producto creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<ProductoResponse> create(
            @Valid @RequestBody ProductoRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(productoService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar producto",
            description = "Permite modificar un producto existente"
    )
    @ApiResponse(responseCode = "200", description = "Producto actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    public ResponseEntity<ProductoResponse> update(
            @Parameter(description = "ID del producto")
            @PathVariable Long id,
            @Valid @RequestBody ProductoRequest request) {

        return ResponseEntity.ok(productoService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar producto",
            description = "Permite eliminar un producto por ID"
    )
    @ApiResponse(responseCode = "204", description = "Producto eliminado correctamente")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del producto")
            @PathVariable Long id) {

        productoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}