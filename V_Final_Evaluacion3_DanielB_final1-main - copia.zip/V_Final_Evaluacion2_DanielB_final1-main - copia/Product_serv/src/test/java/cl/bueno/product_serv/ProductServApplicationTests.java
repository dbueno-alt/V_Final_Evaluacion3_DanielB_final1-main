package cl.bueno.product_serv;

import cl.bueno.product_serv.DTO.ProductoRequest;
import cl.bueno.product_serv.DTO.ProductoResponse;
import cl.bueno.product_serv.service.ProductoService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class ProductServApplicationTests {

    @Autowired
    private ProductoService servicio;

    private Long productoId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            ProductoRequest request = ProductoRequest.builder()
                    .nombre("Notebook Lenovo")
                    .descripcion("Notebook Lenovo IdeaPad 15")
                    .precio(new BigDecimal("799990.00"))
                    .stock(15)
                    .activo(true)
                    .build();

            ProductoResponse response = servicio.create(request);
            productoId = response.getId();

        } else {

            productoId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando nombre del producto")
    void checkNombreProducto() {

        ProductoResponse producto = servicio.findById(productoId);

        log.info("Nombre: {}", producto.getNombre());

        assertEquals("Notebook Lenovo", producto.getNombre());
    }

    @Test
    @DisplayName("Revisando descripción")
    void checkDescripcionProducto() {

        ProductoResponse producto = servicio.findById(productoId);

        log.info("Descripción: {}", producto.getDescripcion());

        assertEquals("Notebook Lenovo IdeaPad 15", producto.getDescripcion());
    }

    @Test
    @DisplayName("Revisando precio")
    void checkPrecioProducto() {

        ProductoResponse producto = servicio.findById(productoId);

        log.info("Precio: {}", producto.getPrecio());

        assertEquals(new BigDecimal("799990.00"), producto.getPrecio());
    }

    @Test
    @DisplayName("Revisando stock")
    void checkStockProducto() {

        ProductoResponse producto = servicio.findById(productoId);

        log.info("Stock: {}", producto.getStock());

        assertEquals(15, producto.getStock());
    }

    @Test
    @DisplayName("Verificando producto activo")
    void checkProductoActivo() {

        ProductoResponse producto = servicio.findById(productoId);

        assertTrue(producto.getActivo());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadProductos() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad productos: {}", cantidad);

        assertEquals(1, cantidad);
    }
}