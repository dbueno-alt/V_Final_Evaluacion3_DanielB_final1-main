package cl.bueno.evaluacion2_danielb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evaluacion2DanielBApplication {

    public static void main(String[] args) {
        SpringApplication.run(Evaluacion2DanielBApplication.class, args);
    }

}
