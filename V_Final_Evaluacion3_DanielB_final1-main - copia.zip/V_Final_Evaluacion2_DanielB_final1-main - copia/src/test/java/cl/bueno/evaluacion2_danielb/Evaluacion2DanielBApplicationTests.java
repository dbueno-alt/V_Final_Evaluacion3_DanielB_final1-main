package cl.bueno.evaluacion2_danielb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Evaluacion2DanielBApplicationTests {

    @Test
    void contextLoads() {
    }

}
