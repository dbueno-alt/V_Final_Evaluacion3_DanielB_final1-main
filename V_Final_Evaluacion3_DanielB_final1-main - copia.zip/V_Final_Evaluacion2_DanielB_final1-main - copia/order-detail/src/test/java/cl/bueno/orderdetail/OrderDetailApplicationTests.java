package cl.bueno.orderdetail;

import cl.bueno.orderdetail.dto.DetallePedidoRequest;
import cl.bueno.orderdetail.dto.DetallePedidoResponse;
import cl.bueno.orderdetail.service.DetallePedidoService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class OrderDetailApplicationTests {

    @Autowired
    private DetallePedidoService servicio;

    private Long detalleId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            BigDecimal precioUnitario = new BigDecimal("100.00");
            Integer cantidad = 2;

            DetallePedidoRequest request = DetallePedidoRequest.builder()
                    .pedidoId(1L)
                    .productoId(1L)
                    .cantidad(cantidad)
                    .precioUnitario(precioUnitario)
                    .build();

            DetallePedidoResponse response = servicio.create(request);
            detalleId = response.getId();

        } else {
            detalleId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando pedidoId")
    void checkPedidoId() {

        DetallePedidoResponse detalle = servicio.findById(detalleId);

        log.info("Pedido ID: {}", detalle.getPedidoId());

        assertEquals(1L, detalle.getPedidoId());
    }

    @Test
    @DisplayName("Revisando productoId")
    void checkProductoId() {

        DetallePedidoResponse detalle = servicio.findById(detalleId);

        log.info("Producto ID: {}", detalle.getProductoId());

        assertEquals(1L, detalle.getProductoId());
    }

    @Test
    @DisplayName("Revisando cantidad")
    void checkCantidad() {

        DetallePedidoResponse detalle = servicio.findById(detalleId);

        log.info("Cantidad: {}", detalle.getCantidad());

        assertEquals(2, detalle.getCantidad());
    }

    @Test
    @DisplayName("Revisando precio unitario")
    void checkPrecioUnitario() {

        DetallePedidoResponse detalle = servicio.findById(detalleId);

        log.info("Precio unitario: {}", detalle.getPrecioUnitario());

        assertEquals(new BigDecimal("100.00"), detalle.getPrecioUnitario());
    }

    @Test
    @DisplayName("Revisando subtotal calculado")
    void checkSubtotal() {

        DetallePedidoResponse detalle = servicio.findById(detalleId);

        log.info("Subtotal: {}", detalle.getSubtotal());

        assertEquals(new BigDecimal("200.00"), detalle.getSubtotal());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadRegistros() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad de registros: {}", cantidad);

        assertEquals(1, cantidad);
    }
}