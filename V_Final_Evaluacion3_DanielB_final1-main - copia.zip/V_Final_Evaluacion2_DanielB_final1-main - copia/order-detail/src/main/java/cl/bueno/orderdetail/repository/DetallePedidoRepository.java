package cl.bueno.orderdetail.repository;

import cl.bueno.orderdetail.model.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Long> {
}
