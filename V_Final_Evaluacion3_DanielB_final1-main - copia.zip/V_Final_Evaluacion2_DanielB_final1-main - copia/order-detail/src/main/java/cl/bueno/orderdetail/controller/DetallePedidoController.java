package cl.bueno.orderdetail.controller;

import cl.bueno.orderdetail.dto.DetallePedidoRequest;
import cl.bueno.orderdetail.dto.DetallePedidoResponse;
import cl.bueno.orderdetail.service.DetallePedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/detalle-pedidos")
@RequiredArgsConstructor
@Tag(name = "API Detalle Pedido", description = "API para la gestión de los detalles de pedidos")
public class DetallePedidoController {

    private final DetallePedidoService detallePedidoService;

    @GetMapping
    @Operation(
            summary = "Obtener todos los detalles de pedidos",
            description = "Permite consultar todos los detalles de pedidos registrados"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen registros")
    public ResponseEntity<List<DetallePedidoResponse>> findAll() {
        return ResponseEntity.ok(detallePedidoService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar detalle de pedido por ID",
            description = "Permite obtener un detalle de pedido mediante su ID"
    )
    @ApiResponse(responseCode = "200", description = "Detalle encontrado")
    @ApiResponse(responseCode = "404", description = "Detalle no encontrado")
    public ResponseEntity<DetallePedidoResponse> findById(
            @Parameter(description = "ID del detalle de pedido")
            @PathVariable Long id) {

        return ResponseEntity.ok(detallePedidoService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Crear detalle de pedido",
            description = "Permite registrar un nuevo detalle de pedido"
    )
    @ApiResponse(responseCode = "201", description = "Detalle creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<DetallePedidoResponse> create(
            @Valid @RequestBody DetallePedidoRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(detallePedidoService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar detalle de pedido",
            description = "Permite modificar un detalle de pedido existente"
    )
    @ApiResponse(responseCode = "200", description = "Detalle actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Detalle no encontrado")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<DetallePedidoResponse> update(
            @Parameter(description = "ID del detalle de pedido")
            @PathVariable Long id,
            @Valid @RequestBody DetallePedidoRequest request) {

        return ResponseEntity.ok(detallePedidoService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar detalle de pedido",
            description = "Permite eliminar un detalle de pedido mediante su ID"
    )
    @ApiResponse(responseCode = "204", description = "Detalle eliminado correctamente")
    @ApiResponse(responseCode = "404", description = "Detalle no encontrado")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del detalle de pedido")
            @PathVariable Long id) {

        detallePedidoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}