package cl.bueno.orderdetail.service;

import cl.bueno.orderdetail.dto.DetallePedidoRequest;
import cl.bueno.orderdetail.dto.DetallePedidoResponse;
import cl.bueno.orderdetail.exception.RecursoNoEncontradoException;
import cl.bueno.orderdetail.model.DetallePedido;
import cl.bueno.orderdetail.repository.DetallePedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DetallePedidoService {

    private final DetallePedidoRepository detallePedidoRepository;

    public List<DetallePedidoResponse> findAll() {
        return detallePedidoRepository.findAll().stream().map(this::toResponse).toList();
    }

    public DetallePedidoResponse findById(Long id) {
        DetallePedido detalle = detallePedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Detalle de pedido no encontrado"));
        return toResponse(detalle);
    }

    public DetallePedidoResponse create(DetallePedidoRequest request) {
        BigDecimal subtotal = request.getPrecioUnitario().multiply(BigDecimal.valueOf(request.getCantidad()));

        DetallePedido detalle = DetallePedido.builder()
                .pedidoId(request.getPedidoId())
                .productoId(request.getProductoId())
                .cantidad(request.getCantidad())
                .precioUnitario(request.getPrecioUnitario())
                .subtotal(subtotal)
                .build();

        return toResponse(detallePedidoRepository.save(detalle));
    }

    public DetallePedidoResponse update(Long id, DetallePedidoRequest request) {
        DetallePedido detalle = detallePedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Detalle de pedido no encontrado"));

        BigDecimal subtotal = request.getPrecioUnitario().multiply(BigDecimal.valueOf(request.getCantidad()));

        detalle.setPedidoId(request.getPedidoId());
        detalle.setProductoId(request.getProductoId());
        detalle.setCantidad(request.getCantidad());
        detalle.setPrecioUnitario(request.getPrecioUnitario());
        detalle.setSubtotal(subtotal);

        return toResponse(detallePedidoRepository.save(detalle));
    }

    public void delete(Long id) {
        if (!detallePedidoRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Detalle de pedido no encontrado");
        }
        detallePedidoRepository.deleteById(id);
    }

    private DetallePedidoResponse toResponse(DetallePedido detalle) {
        return DetallePedidoResponse.builder()
                .id(detalle.getId())
                .pedidoId(detalle.getPedidoId())
                .productoId(detalle.getProductoId())
                .cantidad(detalle.getCantidad())
                .precioUnitario(detalle.getPrecioUnitario())
                .subtotal(detalle.getSubtotal())
                .build();
    }
}
