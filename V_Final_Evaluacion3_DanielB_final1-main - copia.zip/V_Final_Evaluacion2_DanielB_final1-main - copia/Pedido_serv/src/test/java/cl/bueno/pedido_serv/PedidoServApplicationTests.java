package cl.bueno.pedido_serv;

import cl.bueno.pedido_serv.dto.PedidoRequest;
import cl.bueno.pedido_serv.dto.PedidoResponse;
import cl.bueno.pedido_serv.service.PedidoService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class PedidoApplicationTests {

    @Autowired
    private PedidoService servicio;

    private Long pedidoId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            PedidoRequest request = PedidoRequest.builder()
                    .clienteId(1L)
                    .fechaPedido(LocalDateTime.now())
                    .estado("CREADO")
                    .total(new BigDecimal("15000"))
                    .observacion("Pedido de prueba")
                    .build();

            PedidoResponse response = servicio.create(request);
            pedidoId = response.getId();

        } else {
            pedidoId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {}

    @Test
    @DisplayName("Validar clienteId del pedido")
    void checkClienteId() {
        PedidoResponse pedido = servicio.findById(pedidoId);
        log.info("Cliente ID: {}", pedido.getClienteId());
        assertEquals(1L, pedido.getClienteId());
    }

    @Test
    @DisplayName("Validar estado del pedido")
    void checkEstado() {
        PedidoResponse pedido = servicio.findById(pedidoId);
        assertEquals("CREADO", pedido.getEstado());
    }

    @Test
    @DisplayName("Validar total del pedido")
    void checkTotal() {
        PedidoResponse pedido = servicio.findById(pedidoId);
        assertEquals(0, new BigDecimal("15000").compareTo(pedido.getTotal()));
    }

    @Test
    @DisplayName("Validar observación")
    void checkObservacion() {
        PedidoResponse pedido = servicio.findById(pedidoId);
        assertEquals("Pedido de prueba", pedido.getObservacion());
    }

    @Test
    @DisplayName("Validar cantidad de pedidos")
    void checkCantidad() {
        int cantidad = servicio.findAll().size();
        assertTrue(cantidad >= 1);
    }
}