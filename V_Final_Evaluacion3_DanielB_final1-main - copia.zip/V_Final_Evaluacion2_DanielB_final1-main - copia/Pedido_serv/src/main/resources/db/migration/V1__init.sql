CREATE TABLE pedidos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id BIGINT NOT NULL,
    fecha_pedido DATETIME NOT NULL,
    estado varchar(30) NOT NULL,
    total decimal(10,2) NOT NULL,
    observacion varchar(255)
);