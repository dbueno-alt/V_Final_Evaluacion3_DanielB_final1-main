package cl.bueno.pedido_serv.controller;

import cl.bueno.pedido_serv.dto.PedidoRequest;
import cl.bueno.pedido_serv.dto.PedidoResponse;
import cl.bueno.pedido_serv.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/pedidos")
@RequiredArgsConstructor
@Tag(name = "API Pedido", description = "API para la gestión de pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    @GetMapping
    @Operation(
            summary = "Obtener todos los pedidos",
            description = "Permite consultar todos los pedidos registrados"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen pedidos registrados")
    public ResponseEntity<List<PedidoResponse>> findAll() {
        return ResponseEntity.ok(pedidoService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar pedido por ID",
            description = "Permite obtener un pedido mediante su ID"
    )
    @ApiResponse(responseCode = "200", description = "Pedido encontrado")
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    public ResponseEntity<PedidoResponse> findById(
            @Parameter(description = "ID del pedido")
            @PathVariable Long id) {

        return ResponseEntity.ok(pedidoService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar un pedido",
            description = "Permite registrar un nuevo pedido"
    )
    @ApiResponse(responseCode = "201", description = "Pedido creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<PedidoResponse> create(
            @Valid @RequestBody PedidoRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(pedidoService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar pedido",
            description = "Permite modificar un pedido existente"
    )
    @ApiResponse(responseCode = "200", description = "Pedido actualizado correctamente")
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<PedidoResponse> update(
            @Parameter(description = "ID del pedido")
            @PathVariable Long id,
            @Valid @RequestBody PedidoRequest request) {

        return ResponseEntity.ok(pedidoService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar pedido",
            description = "Permite eliminar un pedido mediante su ID"
    )
    @ApiResponse(responseCode = "204", description = "Pedido eliminado correctamente")
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del pedido")
            @PathVariable Long id) {

        pedidoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}