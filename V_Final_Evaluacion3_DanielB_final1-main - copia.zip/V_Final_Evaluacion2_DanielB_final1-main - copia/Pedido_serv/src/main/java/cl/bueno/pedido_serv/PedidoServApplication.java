package cl.bueno.pedido_serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoServApplication {

    public static void main(String[] args) {
        SpringApplication.run(PedidoServApplication.class, args);
    }

}
