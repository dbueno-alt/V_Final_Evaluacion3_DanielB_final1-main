package cl.bueno.pedido_serv.repository;

import cl.bueno.pedido_serv.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}
