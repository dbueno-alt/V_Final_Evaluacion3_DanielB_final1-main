package cl.bueno.pedido_serv.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PedidoResponse {
    private Long id;
    private Long clienteId;
    private LocalDateTime fechaPedido;
    private String estado;
    private BigDecimal total;
    private String observacion;
}