package cl.bueno.pedido_serv.service;

import cl.bueno.pedido_serv.dto.PedidoRequest;
import cl.bueno.pedido_serv.dto.PedidoResponse;
import cl.bueno.pedido_serv.exception.RecursoNoEncontradoException;
import cl.bueno.pedido_serv.model.Pedido;
import cl.bueno.pedido_serv.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PedidoService {

    private final PedidoRepository pedidoRepository;

    public List<PedidoResponse> findAll() {
        return pedidoRepository.findAll().stream().map(this::toResponse).toList();
    }

    public PedidoResponse findById(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pedido no encontrado"));
        return toResponse(pedido);
    }

    public PedidoResponse create(PedidoRequest request) {
        Pedido pedido = Pedido.builder()
                .clienteId(request.getClienteId())
                .fechaPedido(request.getFechaPedido())
                .estado(request.getEstado())
                .total(request.getTotal())
                .observacion(request.getObservacion())
                .build();

        return toResponse(pedidoRepository.save(pedido));
    }

    public PedidoResponse update(Long id, PedidoRequest request) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pedido no encontrado"));

        pedido.setClienteId(request.getClienteId());
        pedido.setFechaPedido(request.getFechaPedido());
        pedido.setEstado(request.getEstado());
        pedido.setTotal(request.getTotal());
        pedido.setObservacion(request.getObservacion());

        return toResponse(pedidoRepository.save(pedido));
    }

    public void delete(Long id) {
        if (!pedidoRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Pedido no encontrado");
        }
        pedidoRepository.deleteById(id);
    }

    private PedidoResponse toResponse(Pedido pedido) {
        return PedidoResponse.builder()
                .id(pedido.getId())
                .clienteId(pedido.getClienteId())
                .fechaPedido(pedido.getFechaPedido())
                .estado(pedido.getEstado())
                .total(pedido.getTotal())
                .observacion(pedido.getObservacion())
                .build();
    }
}
