package cl.bueno.categoria_serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoriaServApplication {

    public static void main(String[] args) {
        SpringApplication.run(CategoriaServApplication.class, args);
    }

}
