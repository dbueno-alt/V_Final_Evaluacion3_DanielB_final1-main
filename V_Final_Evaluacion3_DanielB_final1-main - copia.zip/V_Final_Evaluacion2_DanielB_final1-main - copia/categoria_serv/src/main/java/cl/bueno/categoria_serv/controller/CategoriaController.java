package cl.bueno.categoria_serv.controller;

import cl.bueno.categoria_serv.dto.CategoriaRequest;
import cl.bueno.categoria_serv.dto.CategoriaResponse;
import cl.bueno.categoria_serv.service.CategoriaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/categorias")
@RequiredArgsConstructor
@Tag(name = "API Categoría", description = "API para la gestión de categorías")
public class CategoriaController {

    private final CategoriaService categoriaService;

    @GetMapping
    @Operation(
            summary = "Obtener todas las categorías",
            description = "Permite consultar todas las categorías registradas"
    )
    @ApiResponse(responseCode = "200", description = "Consulta realizada correctamente")
    @ApiResponse(responseCode = "204", description = "No existen categorías registradas")
    public ResponseEntity<List<CategoriaResponse>> findAll() {

        List<CategoriaResponse> categorias = categoriaService.findAll();

        if (categorias.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(categorias, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar categoría por ID",
            description = "Obtiene una categoría según su identificador"
    )
    @ApiResponse(responseCode = "200", description = "Categoría encontrada")
    @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    public ResponseEntity<CategoriaResponse> findById(
            @Parameter(description = "ID de la categoría")
            @PathVariable Long id) {

        return ResponseEntity.ok(categoriaService.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar categoría",
            description = "Permite registrar una nueva categoría"
    )
    @ApiResponse(responseCode = "201", description = "Categoría registrada correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    public ResponseEntity<CategoriaResponse> create(
            @Valid @RequestBody CategoriaRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(categoriaService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar categoría",
            description = "Actualiza los datos de una categoría existente"
    )
    @ApiResponse(responseCode = "200", description = "Categoría actualizada correctamente")
    @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    public ResponseEntity<CategoriaResponse> update(
            @Parameter(description = "ID de la categoría")
            @PathVariable Long id,
            @Valid @RequestBody CategoriaRequest request) {

        return ResponseEntity.ok(categoriaService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar categoría",
            description = "Elimina una categoría del sistema"
    )
    @ApiResponse(responseCode = "204", description = "Categoría eliminada correctamente")
    @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID de la categoría")
            @PathVariable Long id) {

        categoriaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}