CREATE TABLE categorias (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            nombre varchar(100) NOT NULL,
            descripcion varchar(255) NOT NULL,
            activo BOOLEAN NOT NULL DEFAULT TRUE
);