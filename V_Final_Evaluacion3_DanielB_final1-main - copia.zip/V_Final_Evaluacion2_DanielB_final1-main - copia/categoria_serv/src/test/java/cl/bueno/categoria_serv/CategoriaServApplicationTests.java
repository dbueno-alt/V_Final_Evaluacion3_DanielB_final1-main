package cl.bueno.categoria_serv;

import cl.bueno.categoria_serv.dto.CategoriaRequest;
import cl.bueno.categoria_serv.dto.CategoriaResponse;
import cl.bueno.categoria_serv.service.CategoriaService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@SpringBootTest
@ActiveProfiles("test")
class CategoriaApplicationTests {

    @Autowired
    private CategoriaService servicio;

    private Long categoriaId;

    @BeforeEach
    void cargarDatos() {

        if (servicio.findAll().isEmpty()) {

            CategoriaRequest request = CategoriaRequest.builder()
                    .nombre("Tecnología")
                    .descripcion("Productos tecnológicos")
                    .activo(true)
                    .build();

            CategoriaResponse response = servicio.create(request);
            categoriaId = response.getId();

        } else {

            categoriaId = servicio.findAll().get(0).getId();
        }
    }

    @Test
    void contextLoads() {
    }

    @Test
    @DisplayName("Revisando nombre de la categoría")
    void checkNombreCategoria() {

        CategoriaResponse categoria = servicio.findById(categoriaId);

        log.info("Revisando categoría {}", categoria.getNombre());

        assertEquals("Tecnología", categoria.getNombre());
    }

    @Test
    @DisplayName("Revisando descripción de la categoría")
    void checkDescripcionCategoria() {

        CategoriaResponse categoria = servicio.findById(categoriaId);

        log.info("Revisando descripción {}", categoria.getDescripcion());

        assertEquals("Productos tecnológicos", categoria.getDescripcion());
    }

    @Test
    @DisplayName("Verificando estado activo")
    void checkCategoriaActiva() {

        CategoriaResponse categoria = servicio.findById(categoriaId);

        log.info("Verificando estado de categoría");

        assertTrue(categoria.getActivo());
    }

    @Test
    @DisplayName("Verificando cantidad de registros")
    void checkCantidadCategorias() {

        int cantidad = servicio.findAll().size();

        log.info("Cantidad de categorías: {}", cantidad);

        assertEquals(1, cantidad);
    }
}